// Starts the sharding process
require('./src/sharding');
