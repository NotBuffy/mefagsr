# Config files
- `bot-config.js` includes the bot configs like the bot name, status, Discord token, etc...
- `logging-config.js` includes some logging configuration options
- `commands-config.js` includes important settings like the prefix, and some cooldown options for the commands
