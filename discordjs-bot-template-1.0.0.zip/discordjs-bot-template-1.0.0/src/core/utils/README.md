# Utils

## Logger
Simple colourful logger that uses [beautify.log](https://github.com/lucasgdb/beautify.log) to format console logs.  

There are some default logging options that can be modified in the `logging-config.json` file in the `src/config` folder.  

## Cooldowns manager
Includes a command cooldown system taken from the [discordjs.guide](https://discordjs.guide/command-handling/adding-features.html#cooldowns).  

## Tips
A simple tip system for the bot.
