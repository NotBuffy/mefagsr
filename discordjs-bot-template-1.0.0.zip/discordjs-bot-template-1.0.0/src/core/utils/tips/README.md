# Tips
A simple tip system for the bot.
Basically the bot occasionally (randomly) sends users a message when they interact with the bot to notify them about certain news / aspects of the bot.  

You should place the bot tips in the `tips.json` file.  
The file `tips-manager.js` includes a method to get a random tip from that json file.
