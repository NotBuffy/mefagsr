module.exports = {
   primary: '#000',
   info: '#43b581',
   error: '#faa619',
   warn: '#f14846',
};
