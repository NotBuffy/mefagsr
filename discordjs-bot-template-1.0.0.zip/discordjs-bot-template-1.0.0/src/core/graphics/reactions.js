module.exports = {
   wave: '👋',
};
