# Graphics
- `colors.js` contains some colors that the bot uses for embed replies or other aesthetic elements.
- `embeds.js` includes some default and useful embed messages for the bot replies, you should customise them to your likings.
- `reactions.js` is a file where you can include custom or standard emojis / discord reactions so that you can simply require that file in your command and use them.
