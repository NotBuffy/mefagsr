# Discord utils
Some useful files that are related to Discord.

## Permissions Handler
This file contains some useful methods for permissions checking, mainly to check if the bot
has the required permissions in:
- a server
- a text channel
- a voice channel

You can modify what permissions the bot needs in this file!
